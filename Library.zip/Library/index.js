const express = require("express");
const port = 8080;
const app = express();
app.use(express.json());
app.set("view engine", "ejs");
app.set("views", "./views");

app.listen(port, ()=>{
    console.log(`Server is running at ${port}`);
});

let book  = [
    {
         id : 0,
         Title: "Mathematics",
         Author:"Nagarjun"
    },

    {
        id : 1,
        Title: "Physics",
        Author:"R.D. Sharma"

    },

    {
        id : 2,
        Title: "Chemistry",
        Author:"Mark Wood"
    }
]

app.get("/books", (req, res) => {
    res.render("index.ejs");
    console.log(`Showing all the books for there`);
});


app.get("/books/:id", (req, res) => {
    let { id } = req.params;
    id = parseInt(id);
    if (id < 0 || id >= book.length) {
        return res.status(404).send("Book not found.");
    }
    res.json(book[id]);
    console.log(`Show the book which has id = ${id}`);
});


app.post("/books", (req, res) => {
    const { Title, Author } = req.body;
    
    if (!Title || !Author) {
        return res.status(400).send("Title and Author are required.");
    }

    const id = book.length; // Assign new ID dynamically
    book.push({ id, Title, Author });

    res.status(201).json({ message: "Book added successfully", book });
    console.log(`Added book with id = ${id}`);
});


app.put("/books/:id", (req, res) => {
    let { id } = req.params;
    let { Title, Author } = req.body;
    
    id = parseInt(id);
    if (id < 0 || id >= book.length) {
        return res.status(404).send("Book not found.");
    }

    book[id].Title = Title;
    book[id].Author = Author;

    res.redirect("/books");
});

app.delete("/books/:id", (req, res) => {
    let { id } = req.params;
    id = parseInt(id);
    if (id < 0 || id >= book.length) {
        return res.status(404).send("Book not found.");
    }
    book.splice(id, 1);
    res.redirect("/books");
    console.log(`This is delete request for book ${id} !`);
});


app.get("*", (req, res) => {
    res.status(404).send("404 Page Not Found!");
});
 

// Pradeep Soni
// Portfolio: http://www.pradeepsoni.tech/
// 7880606669
// pradeepsoniofficial@gmail.com


